module Stepable
  
  def moves
  #moves should return all positions
  #make something to give us all positions
    #get current position of piece
    curr = self.pos
    #make empty positions_array
    possible_positions = []
    #call self.move_diffs to get array of positions differences
    differences = self.move_diffs

    differences.each do |positions|
      x = curr[0] + positions[0]
      y = curr[1] + positions[1]
      if (x < 8 && x >= 0) && (y < 8 && y >= 0)
        possible_positions << [x,y]
      end
    end

    self.valid_moves(possible_positions)

    #find diff between move_diffs and current position
      #loop through move_diffs
        #find diff between move_diff and current
          #add sub pos of diff from pos of current (pos[0] - diff[0])
        #shovel into positions_array
    #call validmoves to check validity to see if the piece can move there
  end

  private
  def move_diffs
    #knight/king #move_diffs will return movement diffs e.g. [+2, -1] for knight
    return nil
  end
  

end

module Slidable
  def horizonal_dirs
    possible_positions = []
    
    i, j = self.pos[0], self.pos[1]
      while (i < 8 && i >= 0) && (j < 8 && j >= 0)
        i, j = i+1,j+0
        possible_positions << [i, j]
        break if !self.board[[i,j]].empty?
      end
      i, j = self.pos[0], self.pos[1]
      while (i < 8 && i >= 0) && (j < 8 && j >= 0)
        i, j = i-1,j+0
        possible_positions << [i, j]
        break if !self.board[[i,j]].empty?
      end
      i, j = self.pos[0], self.pos[1]
      while (i < 8 && i >= 0) && (j < 8 && j >= 0)
        i, j = i+0,j-1
        possible_positions << [i, j]
        break if !self.board[[i,j]].empty?
      end
      i, j = self.pos[0], self.pos[1]
      while (i < 8 && i >= 0) && (j < 8 && j >= 0)
        i, j = i-0,j+1
        possible_positions << [i, j]
        break if !self.board[[i,j]].empty?
      end
    possible_positions
  end
  
  def diagonal_dirs
    possible_positions = []
    i, j = self.pos[0], self.pos[1]
    while (i < 8 && i >= 0) && (j < 8 && j >= 0)
      i, j = i+1,j+1
      break unless (i < 8 && i >= 0) && (j < 8 && j >= 0) #checks the new position to see if it's with in bounds, break if it does
      possible_positions << [i, j]
       break if !self.board[[i,j]].empty? #checks the new position to see if it contains a piece; break if it does
    end
    i, j = self.pos[0], self.pos[1]
    while (i < 8 && i >= 0) && (j < 8 && j >= 0)
      i, j = i-1,j+1
      break unless (i < 8 && i >= 0) && (j < 8 && j >= 0)
      possible_positions << [i, j]
      break if !self.board[[i,j]].empty?
    end
    i, j = self.pos[0], self.pos[1]
    while (i < 8 && i >= 0) && (j < 8 && j >= 0)
      i, j = i+1,j-1
      break unless (i < 8 && i >= 0) && (j < 8 && j >= 0)
      possible_positions << [i, j]
      break if !self.board[[i,j]].empty?
    end
    i, j = self.pos[0], self.pos[1]
    while (i < 8 && i >= 0) && (j < 8 && j >= 0)
      i, j = i-1,j-1
      break unless (i < 8 && i >= 0) && (j < 8 && j >= 0)
      possible_positions << [i, j]
      break if !self.board[[i,j]].empty?
    end
    possible_positions
  end

  


  def moves
    #create an empty array of moves
    #calling move_dirs and it should return an array of horizontal and/or diagonal
    #if it's horizontal, get horizontal dirs and add it to empty array; if it's diagonal, get diag dirs and add it to array
    possible_moves = []
    direction = self.move_dirs
    if direction.include?("h")
      possible_moves += self.horizonal_dirs
    end
    if direction.include?("d")
      possible_moves += self.diagonal_dirs
    end
    possible_moves

    #check if all moves are valid
    self.valid_moves(possible_moves)

  end

  def move_dirs
    nil
  end

  def grow_unblocked_moves_in_dir(dx, dy)

  end




end



class Piece

  attr_reader :color, :board, :pos

  def initialize(color, board, pos)
    @color, @board, @pos = color, board, pos
    @symbol = nil
  end

  def to_s
  end

  def empty? #return true if NullPiece, otherwise false
    if self.class == NullPiece
      return true 
    else
      return false
    end
  end

  def valid_moves(arr_positions) #check array of positions to make sure there are no positions that are occupied by same colored pieces
    arr_positions.select do |positions|
      self.board[positions].empty? || (self.board[positions].color != self.color)
    end
  end

  def pos=(val)
    @pos = val
  end

  def symbol

  end

  def move_into_check?(end_pos)

  end
end

class Rook < Piece
  include Slidable
  def symbol
    :R
  end

  def move_dirs
    return ['h']
  end

end

class Bishop < Piece
  include Slidable
  def symbol
    :B
  end

  def move_dirs
    return ['d']
  end
end

class Queen < Piece
  include Slidable
  def symbol
    :Q
  end

  def move_dirs
    ['h', 'd']
  end
end

class Knight < Piece
  include Stepable
  def symbol
    :N
  end

  def move_diffs
    #knight/king #move_diffs will return movement diffs e.g. [+2, -1] for knight
    #return every L away from from current position as an array of positions
    return [
      [-2,1], [-1,2],[1,2],[2,1],[-2,-1],[-1,-2],[1,-2],[2,-1]
    ]
  end
end

class King < Piece
  include Stepable
  def symbol
    :K
  end

  def move_diffs
    #knight/king #move_diffs will return movement diffs e.g. [+2, -1] for knight
    #return every 1 away from from current position as an array of positions
    return [[1,1], [1,-1], [-1,1], [-1,-1], [1,0], [0,1], [-1,0], [0,-1]]

  end
end

class Pawn < Piece
  def symbol
    :P
  end

  def move_dirs

  end

  private
  def at_start_row?

  end

  def forward_dir

  end

  def forward_steps

  end

  def side_attacks

  end
end

class NullPiece < Piece
  def initialize(pos)
    super(nil,nil,pos)
  end

  def moves
    
  end

  def symbol
    "."
  end
end

