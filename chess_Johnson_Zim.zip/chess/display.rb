require "colorize"
require_relative "cursor.rb"
require_relative "board.rb"

class Display
  def initialize(board)
    @board = board
    @cursor = Cursor.new([1,1], board)
    main
  end

  def main
    loop do
      render
      @cursor.get_input
    end
  end

  def render
    @board.rows.each do |row|
      row.each do |piece|
        # p @cursor.cursor_pos
        # p piece.pos
        if @cursor.cursor_pos == piece.pos
          print piece.symbol.to_s.colorize(:red)
        else
          print piece.symbol
        end
      end
      puts
    end
    puts
  end

end

b = Board.new
Display.new(b)