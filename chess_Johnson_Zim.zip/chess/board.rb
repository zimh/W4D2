require_relative "piece.rb"

class Board

  attr_reader :rows

  def initialize
    @rows = Array.new(8) {Array.new(8)}
    
    #populating board
    i = 0
    while i < 8
      8.times do |j|
        current = [i,j]
        case current
          when [0,0] , [0,7]#bottom row
            self.add_piece(Rook.new(:white,self,current),current)
          when [0,1] , [0,6]
            self.add_piece(Knight.new(:white,self,current),current)
          when [0,2] , [0,5]
            self.add_piece(Bishop.new(:white,self,current),current)
          when [0,3]
            self.add_piece(Queen.new(:white,self,current),current)
          when [0,4]
            self.add_piece(King.new(:white,self,current),current)
          when [1,j] #second row from bottom
            self.add_piece(Pawn.new(:white,self,current),current)
          when [2,j] , [3,j] , [4,j] , [5,j] #middle empties
            self.add_piece(NullPiece.new(current), current)
          when [6,j] #second row from top
            self.add_piece(Pawn.new(:black,self,current),current)
          when [7,0] , [7,7] #top row
            self.add_piece(Rook.new(:black,self,current),current)
          when [7,1] , [7,6]
            self.add_piece(Knight.new(:black,self,current),current)
          when [7,2] , [7,5]
            self.add_piece(Bishop.new(:black,self,current),current)
          when [7,3]
            self.add_piece(Queen.new(:black,self,current),current)
          when [7,4]
            self.add_piece(King.new(:black,self,current),current)
        end
      end
      i += 1
    end


  end

  def[](pos)
    @rows[pos[0]][pos[1]]
  end

  def[]=(pos, val)
    @rows[pos[0]][pos[1]] = val
  end

  def move_piece(color, start_pos, end_pos)

  end

  def valid_pos?(pos)
     if (pos[0] < 8 && pos[0] >= 0) && (pos[1] < 8 && pos[1] >= 0)
      return true
     else 
      return false
     end
  end

  def add_piece(piece, pos)
    #self.add_piece(piece, pos)
    #grab Piece class
    #set Piece to pos
    self[pos] = piece
    
  end

  def checkmate?(color)

  end

  def in_check?(color)

  end

  def find_king(color)

  end

  def pieces

  end

  def dup

  end
end

# if $PROGRAM_NAME = __FILE__
#   b = Board.new()
#   # puts b.rows
#   b.rows.each do |row|
#     row.each do |piece|
#       print piece.symbol
#     end
#     puts
#   end
# end
# p b[[0,1]].moves
